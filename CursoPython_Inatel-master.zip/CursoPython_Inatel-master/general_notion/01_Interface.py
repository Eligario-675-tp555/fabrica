# gerando uma resposta ao usuario
print("OLA MUNDO!")
print("_________________________________\n")

# criando varias linhas
print("OLA MUNDO! \nSOU UMA NOVA LINHA")
print("__________")
# Ou entao...
print("OLA MUNDO!")
print("SOU UMA NOVA LINHA")
print("_________________________________\n")

# para pedir informações aos usuarios usamos a função chamada INPUT

print("Entre com seu nome")
input()
print("Olá .....?????")

# mas como incluir o nome do usuario no print????
